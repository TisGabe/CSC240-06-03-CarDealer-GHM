# CSC240-07-01-CarDealerShowroom-GHM

## Week 7 Portfolio Improvement – CarDealer Showroom

### Project Description
This Windows Forms application showcases an improved, portfolio-style UI for the
CarDealer project:

- Modern header + banner
- Large model preview images
- Cleaner layout and typography
- Details page with accent color + preview

---

## Git Workflow Used (example)
1. **Initial commit** (main): project scaffold
2. Branch **gui-design**: design MainForm and DetailsForm (controls + fonts/colors)
3. Branch **coding**: add selection logic and open DetailsForm with selected model
4. Create a **Pull Request** and merge branches back into **main**

---

## Screenshot Requirement
Take a screenshot of your GitHub repository Code tab after pushing your final
improvements (and inviting your instructor if required by your class).

---

## How to Run
1. Open `CarDealer.csproj` in Visual Studio
2. Press **Ctrl + F5**
3. Select a model → click **Continue**
4. Click **Back** to return to the main form
